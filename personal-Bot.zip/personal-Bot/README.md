# Smart AI Calendar Assistant Bot 🤖

An intelligent Telegram bot that manages your Cal.com calendar using natural language processing powered by AI.

## Features ✨

- 🗣️ **Natural Language Processing**: Talk to the bot like a human assistant
- 📅 **Smart Calendar Management**: Create, update, delete, and search bookings
- 🤖 **AI-Powered**: Uses AI to understand your requests intelligently
- ⏰ **Flexible Time Parsing**: Understands "tomorrow at 2pm", "next Monday", "in 2 hours", etc.
- 🔍 **Smart Search**: Find bookings by keywords or descriptions
- 📊 **Intelligent Summaries**: Get AI-generated summaries of your schedule
- 🔔 **Cal.com Integration**: Seamless integration with Cal.com scheduling platform

## Setup Instructions 🚀

### 1. Prerequisites

- Python 3.8 or higher
- Cal.com Account (free or paid)
- Telegram Account
- Groq API Key (for AI features)

### 2. Install Dependencies

```bash
pip install -r requirements.txt
```

### 3. Get Cal.com API Key

1. Go to [Cal.com](https://app.cal.com/) and sign in to your account
2. Navigate to **Settings** > **Developer** > **API Keys**
3. Click **Create New API Key**
4. Give it a name (e.g., "Telegram Bot")
5. Copy the generated API key
6. Keep this key safe - you'll need it in the next step

**Important:** Cal.com API requires a paid plan. You can:
- Use Cal.com's free trial
- Subscribe to a paid plan
- Use the API in development mode with limited features

### 4. Get Groq API Key (for AI features)

1. Go to [Groq Console](https://console.groq.com/)
2. Sign up or log in
3. Navigate to API keys section
4. Create a new API key
5. Copy the key for the next step

### 5. Configure Telegram Bot (Already Done ✅)

Your bot is already configured with:
- Bot Token: `8325159356:AAH01SAaRty7rAPcSGr6n4ratGsJcZVKWBI`
- User ID: `906938973`

### 6. Set Up Environment Variables

Create or update your `.env` file with the following:

```env
# Telegram Configuration
TELEGRAM_BOT_TOKEN=your_telegram_bot_token
TELEGRAM_USER_ID=your_telegram_user_id

# Cal.com Configuration
CALCOM_API_KEY=your_calcom_api_key_here
CALCOM_API_URL=https://api.cal.com/v1

# Groq Configuration (for AI features)
GROQ_API_KEY=your_groq_api_key_here
```

### 7. First Run

Run the bot:

```bash
python bot.py
```

The bot will automatically connect to Cal.com using your API key. No browser authentication needed!

## Usage 💬

### Start the bot on Telegram

1. Open Telegram
2. Search for your bot
3. Send `/start` to begin

### Commands

- `/start` - Start the bot and see welcome message
- `/help` - Show help and usage examples
- `/today` - View today's schedule
- `/upcoming` - View upcoming events

### Natural Language Examples

You can talk to the bot naturally. Here are some examples:

**Creating Events:**
- "Schedule a meeting tomorrow at 2pm"
- "Create a dentist appointment next Monday at 10am for 1 hour"
- "Add a team sync every Friday at 3pm"
- "Remind me to call mom at 5pm today"

**Viewing Events:**
- "What's on my calendar today?"
- "Show my schedule for next week"
- "What do I have tomorrow?"
- "List my upcoming events"

**Searching Events:**
- "Find my dentist appointment"
- "Search for meetings with John"
- "Show events about project X"

**Updating Events:**
- "Move tomorrow's meeting to 4pm"
- "Change my dentist appointment to Wednesday"
- "Update the meeting location to Conference Room B"

**Deleting Events:**
- "Cancel my dentist appointment"
- "Delete tomorrow's 2pm meeting"
- "Remove the team sync"

## Project Structure 📁

```
personal-Bot/
├── bot.py                  # Main Telegram bot handler
├── ai_agent.py            # AI agent with Groq integration
├── calendar_manager.py    # Cal.com API manager
├── config.py              # Configuration settings
├── requirements.txt       # Python dependencies
├── .env                   # Environment variables (sensitive)
├── .env.example          # Example environment file
├── .gitignore            # Git ignore rules
└── README.md             # This file
```

## How It Works 🔧

1. **User sends message** to Telegram bot
2. **AI Agent analyzes** the message using Groq AI
3. **Action is determined** (create, read, update, delete booking)
4. **Calendar Manager** executes the action via Cal.com API
5. **Response is generated** and sent back to user

## Features in Detail

### AI-Powered Understanding

The bot uses Groq AI to understand natural language, including:
- Relative dates ("tomorrow", "next week", "in 2 days")
- Flexible time formats ("2pm", "14:00", "2 in the afternoon")
- Context-aware parsing (knows current date/time)
- Intent recognition (create, search, delete, etc.)

### Smart Booking Management

- **Auto-duration**: If you don't specify duration, defaults to 1 hour
- **Time zones**: Handles time zones automatically
- **Cal.com Integration**: Leverages Cal.com's powerful scheduling features
- **Search**: Finds bookings by keywords in title or description

### Privacy & Security

- All credentials stored locally in `.env` file
- Cal.com API key for secure access
- Only authorized user (your User ID) can use the bot

## Troubleshooting 🔧

### "Cal.com API key not found"
Make sure CALCOM_API_KEY is set in your `.env` file (see Setup step 6)

### "Groq API error"
Check that your GROQ_API_KEY is correct in `.env` file and you have credits

### "Cal.com API authentication failed"
Verify your API key is valid. Generate a new one from Cal.com settings if needed

### Bot not responding
1. Check that bot token is correct
2. Ensure bot is running (`python bot.py`)
3. Check for errors in the console
4. Verify Cal.com API key has proper permissions

## Security Notes 🔒

- **Never commit** `.env` file to version control
- Keep your API keys and tokens private
- The `.gitignore` file prevents accidental commits
- Only share this bot with trusted users
- Cal.com API keys have full access to your account - protect them carefully

## Future Enhancements 🚀

Potential features to add:
- Multi-user support
- Recurring events
- Task lists integration
- Email notifications
- Voice message support
- Integration with other calendar services
- Meeting scheduling with availability checking

## Requirements

See `requirements.txt` for all dependencies:
- python-telegram-bot: Telegram bot framework
- requests: HTTP library for Cal.com API
- groq: Groq AI integration
- python-dotenv: Environment variable management
- pytz: Timezone handling

## Support

If you encounter any issues:
1. Check the console logs for error messages
2. Verify all credentials are correctly configured
3. Ensure all dependencies are installed
4. Check that Google Calendar API is enabled

## License

This project is for personal use. Ensure you comply with:
- Cal.com API Terms of Service
- Groq API Terms of Use
- Telegram Bot API Terms

---

**Enjoy your smart AI calendar assistant! 🎉**
#   a s s i s s t e n t  
 